from django.apps import AppConfig


class JpAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jp_app'
